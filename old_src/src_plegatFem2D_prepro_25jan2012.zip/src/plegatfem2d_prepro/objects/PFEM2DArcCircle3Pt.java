/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author jmb2
 */
public class PFEM2DArcCircle3Pt implements IPFEM2DDrawableObject, IPFEM2DMeshableObject,IPFEM2DCurve {

    private PFEM2DPoint centre, pt1, pt2;
    private int id;
    private boolean visible;
    private PFEM2DPoint[] points;
    private int nbPts;
    private boolean meshed;
    private ArrayList<PFEM2DNode> nodes;
    private ArrayList<PFEM2DBeam> elements;
    private int nbElements;
    private double modulus, area, inertia;
    private int meshMethod = IPFEM2DMeshableObject.NODE_AND_BEAM;

    public PFEM2DArcCircle3Pt(int id, PFEM2DPoint centre, PFEM2DPoint pt1, PFEM2DPoint pt2) {
        this.centre = centre;
        this.pt1 = pt1;
        this.pt2 = pt2;
        this.id = id;
        this.visible = true;


        this.meshed = false;
        this.nodes = new ArrayList<PFEM2DNode>();
        this.elements = new ArrayList<PFEM2DBeam>();

        this.nbElements = 1;

        this.init();
    }

    public void init() {

        double radius1 = this.centre.getDistanceTo(this.pt1);
        double radius2 = this.centre.getDistanceTo(this.pt2);

        if (Math.abs(radius1 - radius2) > 1e-5) {

            double x2 = this.centre.getX() + (this.pt2.getX() - this.centre.getX()) / radius2 * radius1;
            double y2 = this.centre.getY() + (this.pt2.getY() - this.centre.getY()) / radius2 * radius1;

            this.pt2.setX(x2);
            this.pt2.setY(y2);

        }

        double dx1 = this.pt1.getX() - this.centre.getX();
        double dy1 = this.pt1.getY() - this.centre.getY();

        double dx2 = this.pt2.getX() - this.centre.getX();
        double dy2 = this.pt2.getY() - this.centre.getY();

        double angle1 = Math.atan2(dy1, dx1);
        double angle2 = Math.atan2(dy2, dx2);

        while (angle2 < angle1) {
            angle2 = angle2 + 2*Math.PI;
        }


        this.nbPts = (int) Math.floor(Math.abs(angle2 - angle1) / (10. / 180 * Math.PI)) + 1;
        double step = (angle2 - angle1) / (this.nbPts - 1);

        /*
        System.out.println("angle1: " + angle1);
        System.out.println("angle2: " + angle2);
        System.out.println("nb pts: " + this.nbPts);
         */
        
        this.points = new PFEM2DPoint[this.nbPts];

        for (int i = 0; i < this.nbPts; i++) {
            this.points[i] = new PFEM2DPoint(0, this.centre.getX() + radius1 * Math.cos(angle1 + i * step), this.centre.getY() + radius1 * Math.sin(angle1 + i * step));
        }


    }

    public PFEM2DPoint getCentre() {
        return centre;
    }

    public void setCentre(PFEM2DPoint centre) {
        this.centre = centre;
    }

    public void setId(int id) {
        this.id = id;
    }

    public PFEM2DPoint getPt1() {
        return pt1;
    }

    public void setPt1(PFEM2DPoint pt) {
        this.pt1 = pt;
    }

    public PFEM2DPoint getPt2() {
        return pt2;
    }

    public void setPt2(PFEM2DPoint pt) {
        this.pt2 = pt;
    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {


        for (int i = 0; i < this.nbPts - 1; i++) {

            g.setColor(Color.yellow);

            int xloc1 = panel.getLocalCoordX(this.points[i].getX());
            int yloc1 = panel.getLocalCoordY(this.points[i].getY());

            int xloc2 = panel.getLocalCoordX(this.points[i + 1].getX());
            int yloc2 = panel.getLocalCoordY(this.points[i + 1].getY());

            g.drawLine(xloc1, yloc1, xloc2, yloc2);


            if (this.isMeshed()) {
                this.drawMesh(g, panel);
            }

        }


    }

    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Circle " + this.id;
    }

    @Override
    public void mesh() {
        if (!this.isMeshed()) {

            double dx1 = this.pt1.getX() - this.centre.getX();
            double dy1 = this.pt1.getY() - this.centre.getY();

            double dx2 = this.pt2.getX() - this.centre.getX();
            double dy2 = this.pt2.getY() - this.centre.getY();

            double angle1 = Math.atan2(dy1, dx1);
            double angle2 = Math.atan2(dy2, dx2);

            while (angle2 < angle1) {
                angle2 = angle2 + 2*Math.PI;
            }

            
            double step = (angle2 - angle1) / this.nbElements;

            /*
            System.out.println("mesh_angle1: " + angle1);
            System.out.println("mesh_angle2: " + angle2);
            System.out.println("mesh_step:   " + step);
             */

            if (!this.pt1.isMeshed()) {
                this.pt1.mesh();
            }
            if (!this.pt2.isMeshed()) {
                this.pt2.mesh();
            }

            PFEM2DNode ndStart = this.pt1.getNode();
            PFEM2DNode ndEnd = this.pt2.getNode();

            this.nodes.add(ndStart);
            this.nodes.add(ndEnd);


            for (int i = 1; i < this.nbElements; i++) {
                this.nodes.add(1, ndStart.getRotated(this.centre, ( i * step) * 180.0 / Math.PI));
            }

            if (this.meshMethod == IPFEM2DMeshableObject.NODE_AND_BEAM) {
                for (int i = 0; i < this.nbElements; i++) {

                    PFEM2DNode nd1 = this.nodes.get(i);
                    PFEM2DNode nd2 = this.nodes.get(i + 1);

                    PFEM2DBeam beam = new PFEM2DBeam(0, nd1, nd2, modulus, area, inertia);

                    this.elements.add(beam);
                }
            }


            this.meshed = true;
            //System.out.println("arc " + this.id + " meshed!");
        }
    }

    @Override
    public void setMeshMethod(int method) {
        this.meshMethod = method;
    }

    @Override
    public void deleteMesh() {
        this.meshed = false;
        this.nodes.clear();
        this.elements.clear();
    }

    @Override
    public boolean isMeshed() {
        return this.meshed;
    }

    @Override
    public PFEM2DNode[] getNodes() {
        PFEM2DNode[] temp = new PFEM2DNode[this.nodes.size()];
        return this.nodes.toArray(temp);
    }

    @Override
    public IPFEM2DElement[] getElements() {
        IPFEM2DElement[] temp = new IPFEM2DElement[this.nodes.size()];
        return this.nodes.toArray(temp);
    }

    public void setNbElements(int nbElements) {
        this.nbElements = nbElements;
    }

    public void setMeshProperties(double modulus, double area, double inertia) {
        this.modulus = modulus;
        this.area = area;
        this.inertia = inertia;
    }

    @Override
    public void drawMesh(Graphics g, PFem2DGuiPanel panel) {

        /*
        System.out.println("drawing mesh for arc " + this.id);
        System.out.println("   nb nodes:    " + this.nodes.size());
        System.out.println("   nb elements: " + this.elements.size());
        */
        
        Iterator<PFEM2DNode> itNode = this.nodes.iterator();

        while (itNode.hasNext()) {
            itNode.next().draw(g, panel);
        }




    }

    @Override
    public PFEM2DPoint getStartPoint() {
        return this.pt1;
    }

    @Override
    public PFEM2DPoint getEndPoint() {
        return this.pt2;
    }
}
