/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

/**
 *
 * @author jmb2
 */
public interface IPFEM2DCurve {

    public PFEM2DPoint getStartPoint();

    public PFEM2DPoint getEndPoint();
}
