/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Arrays;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author jmb2
 */
public class PFEM2DSurface implements IPFEM2DDrawableObject, IPFEM2DMeshableObject {

    private ArrayList<IPFEM2DDrawableObject> objects;
    private boolean visible;
    private long id;
    private boolean meshed;
    private ArrayList<PFEM2DNode> nodes;
    private ArrayList<IPFEM2DElement> elements;
    private double elementMaxSize = 10;
    private double modulus, thickness;
    private int meshMethod = IPFEM2DMeshableObject.DELAUNAY;

    public PFEM2DSurface() {
        this.objects = new ArrayList<IPFEM2DDrawableObject>();

        this.meshed = false;
        this.nodes = new ArrayList<PFEM2DNode>();
        this.elements = new ArrayList<IPFEM2DElement>();

    }

    public void add(IPFEM2DDrawableObject obj) {
        this.objects.add(obj);
    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {
        for (int i = 0; i < this.objects.size(); i++) {

            IPFEM2DDrawableObject obj = this.objects.get(i);

            obj.draw(g, panel);
        }

        if (this.isMeshed()) {
            this.drawMesh(g, panel);
        }
    }

    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Surface " + this.id;
    }

    @Override
    public void mesh() {

        this.deleteMesh();

        if (!this.meshed) {

            for (int i = 0; i < this.objects.size(); i++) {

                IPFEM2DDrawableObject obj = this.objects.get(i);

                if (obj instanceof IPFEM2DMeshableObject) {

                    if (!((IPFEM2DMeshableObject) obj).isMeshed()) {
                        ((IPFEM2DMeshableObject) obj).mesh();
                    }


                }
            }

            if (this.meshMethod == IPFEM2DMeshableObject.DELAUNAY) {
                this.meshDelaunay();
            }

        }


    }

    @Override
    public void setMeshMethod(int method) {
        this.meshMethod = method;
    }

    @Override
    public void deleteMesh() {
        this.meshed = false;
        this.nodes.clear();
        this.elements.clear();
    }

    @Override
    public boolean isMeshed() {
        return this.meshed;
    }

    @Override
    public PFEM2DNode[] getNodes() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public IPFEM2DElement[] getElements() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void drawMesh(Graphics g, PFem2DGuiPanel panel) {

        for (int i = 0; i < this.objects.size(); i++) {

            IPFEM2DDrawableObject obj = this.objects.get(i);

            if (obj instanceof IPFEM2DMeshableObject) {

                ((IPFEM2DMeshableObject) obj).drawMesh(g, panel);

            }
        }

        for (int i = 0; i < this.elements.size(); i++) {

            this.elements.get(i).draw(g, panel);

        }



    }

    public void meshDelaunay() {

        ArrayList<PFEM2DNode> boundaryNodes = new ArrayList<PFEM2DNode>();

        // recuperation des noeuds de la frontiere
        
        for (int i = 0; i < this.objects.size(); i++) {

            IPFEM2DDrawableObject obj = this.objects.get(i);

            if (obj instanceof IPFEM2DMeshableObject) {

                PFEM2DNode[] temp = ((IPFEM2DMeshableObject) obj).getNodes();

                System.out.println("adding nodes from object: " + obj.getId() + ", nb nodes: " + temp.length);

                boundaryNodes.addAll(Arrays.asList(temp));

            }
        }

        double xmin, xmax, ymin, ymax;
        xmin = Double.MAX_VALUE;
        ymin = Double.MAX_VALUE;
        xmax = Double.MIN_VALUE;
        ymax = Double.MIN_VALUE;

        
        // definition de la bounding box

        for (int i = 0; i < boundaryNodes.size(); i++) {

            PFEM2DNode node = boundaryNodes.get(i);

            double x = node.getX();
            double y = node.getY();

            if (x > xmax) {
                xmax = x;
            } else if (x < xmin) {
                xmin = x;
            }

            if (y > ymax) {
                ymax = y;
            } else if (y < ymin) {
                ymin = y;
            }

        }

        System.out.println("bornes: x/" + xmin + "/" + xmax + ", y/" + ymin + "/" + ymax);

        int deltaBox = 20;

        PFEM2DNode nd1 = new PFEM2DNode(1, xmin - deltaBox, ymin - deltaBox);
        PFEM2DNode nd2 = new PFEM2DNode(2, xmax + deltaBox, ymin - deltaBox);
        PFEM2DNode nd3 = new PFEM2DNode(3, xmax + deltaBox, ymax + deltaBox);
        PFEM2DNode nd4 = new PFEM2DNode(4, xmin - deltaBox, ymax + deltaBox);

        this.nodes.add(nd1);
        this.nodes.add(nd2);
        this.nodes.add(nd3);
        this.nodes.add(nd4);

        this.elements.add(new PFEM2DTria(0, nd1, nd2, nd3, 1, 1));
        this.elements.add(new PFEM2DTria(0, nd1, nd3, nd4, 1, 1));

        
        // insertion des noeuds suivant algo de delaunay
        
        ArrayList<PFEM2DTria> trias2remove = new ArrayList<PFEM2DTria>();

        for (int i = 0; i < boundaryNodes.size(); i++) {
            //for (int i = 0; i < 69; i++) {

            PFEM2DNode node = boundaryNodes.get(i);

            trias2remove.clear();

            for (int j = 0; j < this.elements.size(); j++) {

                PFEM2DTria tria = (PFEM2DTria) this.elements.get(j);

                if (tria.isInCircle(node)) {
                    trias2remove.add(tria);
                }
            }

            ArrayList<NodeCouple> couples = new ArrayList<NodeCouple>();

            for (int j = 0; j < trias2remove.size(); j++) {
                this.elements.remove(trias2remove.get(j));

                PFEM2DNode[] triaNodes = trias2remove.get(j).getNodes();

                couples.add(new NodeCouple(triaNodes[0], triaNodes[1]));
                couples.add(new NodeCouple(triaNodes[1], triaNodes[2]));
                couples.add(new NodeCouple(triaNodes[2], triaNodes[0]));
            }

            //nettoyage des couples

            for (int j = couples.size() - 1; j >= 0; j--) {

                NodeCouple nc = couples.get(j);

                for (int k = couples.size() - 1; k > j; k--) {

                    NodeCouple nc2 = couples.get(k);

                    if (nc2.isEqual(nc)) {
                        System.out.println("removing couple " + nc2.toString());
                        couples.remove(k);
                        couples.remove(j);
                        break;
                    }


                }

            }

            //creation des nouveaux trias

            couples.trimToSize();

            for (int j = 0; j < couples.size(); j++) {

                NodeCouple nc = couples.get(j);

                this.elements.add(new PFEM2DTria(0, node, nc.getNd1(), nc.getNd2(), 1, 1));

            }



        }


        // respect de la frontiere

        
        
        
        
        

        
        
        // fin du maillage

        System.out.println("delaunay meshing finished");
        this.meshed = true;

    }
}
