/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Color;
import java.awt.Graphics;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author JMB
 */
public class PFEM2DTria implements IPFEM2DDrawableObject, IPFEM2DElement {

    private PFEM2DNode nd1, nd2, nd3;
    private long id;
    private double modulus, thickness;
    private boolean visible;
    private PFEM2DPoint centre;
    private double radius;

    public PFEM2DTria(long id, PFEM2DNode nd1, PFEM2DNode nd2, PFEM2DNode nd3, double modulus, double thickness) {
        this.nd1 = nd1;
        this.nd2 = nd2;
        this.nd3 = nd3;
        this.id = id;
        this.modulus = modulus;
        this.thickness = thickness;

        this.visible = true;

        this.defCentre();
    }

    public void defCentre() {

        double xab = nd2.getX() - nd1.getX();
        double xca = nd1.getX() - nd3.getX();

        double yab = nd2.getY() - nd1.getY();
        double yca = nd1.getY() - nd3.getY();

        double normeAB = xab * xab + yab * yab;
        double normeCA = xca * xca + yca * yca;

        xab /= normeAB;
        yab /= normeAB;
        xca /= normeCA;
        yca /= normeCA;

        double xd = (nd1.getX() + nd2.getX()) / 2.0;
        double yd = (nd1.getY() + nd2.getY()) / 2.0;
        double xf = (nd1.getX() + nd3.getX()) / 2.0;
        double yf = (nd1.getY() + nd3.getY()) / 2.0;

        double alpha,beta;

        if (Math.abs(yab) < 1e-5) {
            beta = (xd - xf) / yca;
            alpha = (yd - yf + beta * xca) / xab;
        } else {
            beta = (yd - yf - (xf - xd) * xab / yab) / (yca * xab / yab - xca);
            alpha = (xf - xd + beta * yca) / yab;
        }

        this.centre = new PFEM2DPoint(0, xd + alpha * yab, yd - alpha * xab);
        this.radius = this.nd1.getDistanceTo(this.centre);

        /*
        System.out.println("triangle " + this.getId());
        System.out.println("radius1=" + this.nd1.getDistanceTo(this.centre));
        System.out.println("radius2=" + this.nd2.getDistanceTo(this.centre));
        System.out.println("radius2=" + this.nd3.getDistanceTo(this.centre));
        */

    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {

        if (this.isVisible()) {
            int xloc1 = panel.getLocalCoordX(this.nd1.getX());
            int yloc1 = panel.getLocalCoordY(this.nd1.getY());

            int xloc2 = panel.getLocalCoordX(this.nd2.getX());
            int yloc2 = panel.getLocalCoordY(this.nd2.getY());

            int xloc3 = panel.getLocalCoordX(this.nd3.getX());
            int yloc3 = panel.getLocalCoordY(this.nd3.getY());

            int xlocC = (xloc1+xloc2+xloc3)/3;
            int ylocC = (yloc1+yloc2+yloc3)/3;

            double coef=0.85;
            
            xloc1=(int)Math.round(xlocC+coef*(xloc1-xlocC));
            yloc1=(int)Math.round(ylocC+coef*(yloc1-ylocC));

            xloc2=(int)Math.round(xlocC+coef*(xloc2-xlocC));
            yloc2=(int)Math.round(ylocC+coef*(yloc2-ylocC));

            xloc3=(int)Math.round(xlocC+coef*(xloc3-xlocC));
            yloc3=(int)Math.round(ylocC+coef*(yloc3-ylocC));

            
            
            g.setColor(Color.cyan);
            g.drawLine(xloc1, yloc1, xloc2, yloc2);
            g.drawLine(xloc2, yloc2, xloc3, yloc3);
            g.drawLine(xloc3, yloc3, xloc1, yloc1);

            //dessin cercle circonscrit

            /*
            for (int i = 0; i < 36; i++) {

                int xcirc1 = panel.getLocalCoordX(this.centre.getX()+this.radius*Math.cos(i*Math.PI/18.));
                int ycirc1 = panel.getLocalCoordY(this.centre.getY()+this.radius*Math.sin(i*Math.PI/18.));

                int xcirc2 = panel.getLocalCoordX(this.centre.getX()+this.radius*Math.cos((i+1)*Math.PI/18.));
                int ycirc2 = panel.getLocalCoordY(this.centre.getY()+this.radius*Math.sin((i+1)*Math.PI/18.));

                g.setColor(Color.PINK);
                g.drawLine(xcirc1, ycirc1, xcirc2, ycirc2);
            }
*/

        }


    }

    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Tria " + this.id;
    }

    @Override
    public long getNumId() {
        return this.id;
    }

    @Override
    public PFEM2DNode[] getNodes() {

        PFEM2DNode[] tempArray = new PFEM2DNode[3];
        tempArray[0] = this.nd1;
        tempArray[1] = this.nd2;
        tempArray[2] = this.nd3;

        return tempArray;
    }

    @Override
    public PFEM2DNode getNode(int rank) {

        if (rank == 0) {
            return this.nd1;
        } else if (rank == 1) {
            return this.nd2;
        } else if (rank == 2) {
            return this.nd3;
        } else {
            return null;
        }


    }
    
    public boolean isInCircle(PFEM2DNode node) {
        
        if (node.getDistanceTo(this.centre)<=(this.radius+1e-8)) {
            return true;
        } else {
            return false;
        }
        
    }
}
