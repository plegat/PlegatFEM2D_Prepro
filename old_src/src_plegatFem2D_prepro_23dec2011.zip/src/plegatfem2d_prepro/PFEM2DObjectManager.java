/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro;

import plegatfem2d_prepro.objects.IPFEM2DDrawableObject;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author jmb2
 */
public class PFEM2DObjectManager {

    public PFEM2DObjectManager() {
        this.objects = new ArrayList<IPFEM2DDrawableObject>();

    }

    public void init() {
        this.objects.clear();
    }

    public void addObject(IPFEM2DDrawableObject obj) {
        this.objects.add(obj);
    }

    public void removeObject(int rank) {
        this.objects.remove(rank);
    }

    public void removeObject(IPFEM2DDrawableObject obj) {
        this.objects.remove(obj);
    }

    public void draw(Graphics g, PFem2DGuiPanel panel) {

        Iterator<IPFEM2DDrawableObject> it = this.objects.iterator();

        while (it.hasNext()) {
            
            IPFEM2DDrawableObject obj=it.next();
            
            //System.out.println("drawing object "+obj.getId());
            
            obj.draw(g, panel);
        }

    }
    private ArrayList<IPFEM2DDrawableObject> objects;
}
