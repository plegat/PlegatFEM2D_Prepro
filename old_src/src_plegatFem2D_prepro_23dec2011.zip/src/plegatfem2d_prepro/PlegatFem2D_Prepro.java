/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JSeparator;
import javax.swing.JToolBar;
import plegatfem2d_prepro.objects.PFEM2DArcCircle3Pt;
import plegatfem2d_prepro.objects.PFEM2DCircle2Pt;
import plegatfem2d_prepro.objects.PFEM2DLine;
import plegatfem2d_prepro.objects.PFEM2DNode;
import plegatfem2d_prepro.objects.PFEM2DPoint;

/**
 *
 * @author jmb2
 */
public class PlegatFem2D_Prepro extends JFrame {

    public PlegatFem2D_Prepro(String frameTitle) {
        super(frameTitle);

        this.initComponents();


    }

    private void initComponents() {

        this.pfguipanel = new PFem2DGuiPanel();
        this.pfguipanel.setPreferredSize(new Dimension(800, 600));
        this.add(this.pfguipanel, BorderLayout.CENTER);

        JToolBar toolbar = new JToolBar();
        toolbar.setPreferredSize(new Dimension(100, 40));

        toolbar.add(new JButton("open", new javax.swing.ImageIcon(getClass().getResource("/ressources/icons/document-open.png"))));
        toolbar.add(new JButton("mesh", new javax.swing.ImageIcon(getClass().getResource("/ressources/icons/applications-system.png"))));
        toolbar.add(new JButton("screen", new javax.swing.ImageIcon(getClass().getResource("/ressources/icons/camera-photo.png"))));
        toolbar.add(new JSeparator(JSeparator.VERTICAL));

        JButton jbClose = new JButton("close", new javax.swing.ImageIcon(getClass().getResource("/ressources/icons/process-stop.png")));
        jbClose.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        toolbar.add(jbClose);


        this.add(toolbar, BorderLayout.NORTH);

        this.pack();

        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        PFEM2DObjectManager pom = new PFEM2DObjectManager();

        /*
        
        for (int i = 0; i < 36; i++) {
            pom.addObject(new PFEM2DNode((i+1), 20*Math.cos(i*10./180*Math.PI),20*Math.sin(i*10./180*Math.PI)));

        }

        PFEM2DPoint[] pts=new PFEM2DPoint[36];
        for (int i = 0; i < 36; i++) {
            pts[i]=new PFEM2DPoint((i+1), 30+20*Math.cos(i*10./180*Math.PI),10+20*Math.sin(i*10./180*Math.PI));
            pom.addObject(pts[i]);

        }

        for (int i = 0; i < 36; i++) {
            if (i<35) {
            pom.addObject(new PFEM2DLine(100+i, pts[i], pts[i+1]));
            } else {
            pom.addObject(new PFEM2DLine(100+i, pts[35], pts[0]));
            }
        }
        
        PFEM2DPoint pt200=new PFEM2DPoint(200, 50, 50);
        PFEM2DPoint pt201=new PFEM2DPoint(201, 75, 60);
        
        pom.addObject(pt200);
        pom.addObject(pt201);
        
        PFEM2DCircle2Pt circle202=new PFEM2DCircle2Pt(202, pt200, pt201);
        pom.addObject(circle202);

        PFEM2DPoint pt300=new PFEM2DPoint(300, 150, 50);
        PFEM2DPoint pt301=new PFEM2DPoint(301, 200, 50);
        PFEM2DPoint pt302=pt301.getRotated(pt300, -60);
        
        PFEM2DArcCircle3Pt arc303=new PFEM2DArcCircle3Pt(303, pt300, pt301, pt302);
        
        pom.addObject(pt301);
        pom.addObject(pt302);
        pom.addObject(arc303);
        
        
        
        
         */
        
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 10; j++) {
                
                PFEM2DPoint centre=new PFEM2DPoint(0,10+i*50,10+j*50);
                PFEM2DPoint pt=new PFEM2DPoint(0,10+i*50+20,10+j*50);
                
                PFEM2DCircle2Pt circle=new PFEM2DCircle2Pt(i*100+j, centre, pt);
                
                pom.addObject(circle);
                
            }
            
        }
        
        
        
        this.pfguipanel.setPom(pom);

    }
    private PFem2DGuiPanel pfguipanel;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                new PlegatFem2D_Prepro("Preprocesseur PFEM").setVisible(true);

                System.out.println("lancement ok");
            }
        });



    }
}
