/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Color;
import java.awt.Graphics;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author jmb2
 */
public class PFEM2DPoint implements IPFEM2DDrawableObject {

    private double x, y;
    private long id;
    private boolean visible;

    public PFEM2DPoint(long id, double x, double y) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.visible = true;
    }

    public PFEM2DPoint() {
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {

        if (this.isVisible()) {
            int xloc = panel.getLocalCoordX(this.x);
            int yloc = panel.getLocalCoordY(this.y);

            int[] xPoints = {xloc + 5, xloc - 5, xloc - 5, xloc + 5, xloc + 5};
            int[] yPoints = {yloc + 5, yloc + 5, yloc - 5, yloc - 5, yloc + 5};


            g.setColor(Color.cyan);
            g.drawPolyline(xPoints, yPoints, 5);
        }

    }

    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Point " + this.id;
    }
    
    public double getDistanceTo(PFEM2DPoint pt) {
        return Math.sqrt(Math.pow(pt.getX()-this.getX(),2)+Math.pow(pt.getY()-this.getY(),2));
    }
    
    public PFEM2DPoint getRotated(PFEM2DPoint centre,double angle) {
        
        double dx=this.getX()-centre.getX();
        double dy=this.getY()-centre.getY();
        
        double angleBase=Math.atan2(dy, dx);
        double radius=centre.getDistanceTo(this);
        
        double xRot=centre.getX()+radius*Math.cos(angleBase+angle/180.*Math.PI);
        double yRot=centre.getY()+radius*Math.sin(angleBase+angle/180.*Math.PI);
        
        return new PFEM2DPoint(0, xRot, yRot);
        
        
    }
}
