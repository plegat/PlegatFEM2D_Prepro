/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Color;
import java.awt.Graphics;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author jmb2
 */
public class PFEM2DCircle2Pt implements IPFEM2DDrawableObject {
    
    private PFEM2DPoint centre,pt;
    private int id;
    private boolean visible;
    
    private PFEM2DPoint[] points;
    private static int NB_PTS=36;

    public PFEM2DCircle2Pt(int id,PFEM2DPoint centre, PFEM2DPoint pt ) {
        this.centre = centre;
        this.pt = pt;
        this.id = id;
        this.visible=true;
        
        this.init();
    }

    public void init() {
        this.points=new PFEM2DPoint[NB_PTS+1];
        
        double radius=this.centre.getDistanceTo(this.pt);
        
        for (int i = 0; i < NB_PTS; i++) {
            this.points[i]=new PFEM2DPoint(0, this.centre.getX()+radius*Math.cos(i/18.*Math.PI), this.centre.getY()+radius*Math.sin(i/18.*Math.PI));
        }
        
        this.points[NB_PTS]=this.points[0];
    }
    
    public PFEM2DPoint getCentre() {
        return centre;
    }

    public void setCentre(PFEM2DPoint centre) {
        this.centre = centre;
    }

    public void setId(int id) {
        this.id = id;
    }

    public PFEM2DPoint getPt() {
        return pt;
    }

    public void setPt(PFEM2DPoint pt) {
        this.pt = pt;
    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {
        
        g.setColor(Color.yellow);
        
        for (int i = 0; i < NB_PTS; i++) {
            
            int xloc1 = panel.getLocalCoordX(this.points[i].getX());
            int yloc1 = panel.getLocalCoordY(this.points[i].getY());

            int xloc2 = panel.getLocalCoordX(this.points[i+1].getX());
            int yloc2 = panel.getLocalCoordY(this.points[i+1].getY());

            g.drawLine(xloc1, yloc1, xloc2, yloc2);
            
            
        }
        
        
    }

    @Override
    public void setVisible(boolean flag) {
        this.visible=flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Circle "+this.id;
    }
    
    
    
    
}
