/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Color;
import java.awt.Graphics;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author jmb2
 */
public class PFEM2DLine implements IPFEM2DDrawableObject {

    private PFEM2DPoint pt1, pt2;
    private int id;
    private boolean visible;

    public PFEM2DLine(int id, PFEM2DPoint pt1, PFEM2DPoint pt2) {
        this.pt1 = pt1;
        this.pt2 = pt2;
        this.id = id;
        this.visible = true;
    }

    public PFEM2DLine() {
    }

    public void setId(int id) {
        this.id = id;
    }

    public PFEM2DPoint getPt1() {
        return pt1;
    }

    public void setPt1(PFEM2DPoint pt1) {
        this.pt1 = pt1;
    }

    public PFEM2DPoint getPt2() {
        return pt2;
    }

    public void setPt2(PFEM2DPoint pt2) {
        this.pt2 = pt2;
    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {

        if (this.isVisible()) {
            int xloc1 = panel.getLocalCoordX(this.pt1.getX());
            int yloc1 = panel.getLocalCoordY(this.pt1.getY());

            int xloc2 = panel.getLocalCoordX(this.pt2.getX());
            int yloc2 = panel.getLocalCoordY(this.pt2.getY());


            g.setColor(Color.yellow);
            g.drawLine(xloc1, yloc1, xloc2, yloc2);
        }
    }

    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Line " + this.id;
    }
}
