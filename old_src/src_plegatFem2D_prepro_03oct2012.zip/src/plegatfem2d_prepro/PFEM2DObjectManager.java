/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import plegatfem2d_prepro.objects.IPFEM2DDrawableObject;
import plegatfem2d_prepro.objects.IPFEM2DElement;
import plegatfem2d_prepro.objects.IPFEM2DMeshableObject;
import plegatfem2d_prepro.objects.PFEM2DNode;

/**
 *
 * @author jmb2
 */
public class PFEM2DObjectManager {

    public PFEM2DObjectManager() {
        this.objects = new ArrayList<IPFEM2DDrawableObject>();

    }

    public void init() {
        this.objects.clear();
    }

    public void addObject(IPFEM2DDrawableObject obj) {
        this.objects.add(obj);
    }

    public void removeObject(int rank) {
        this.objects.remove(rank);
    }

    public void removeObject(IPFEM2DDrawableObject obj) {
        this.objects.remove(obj);
    }

    public void draw(Graphics g, PFem2DGuiPanel panel) {

        Iterator<IPFEM2DDrawableObject> it = this.objects.iterator();

        while (it.hasNext()) {

            IPFEM2DDrawableObject obj = it.next();

            //System.out.println("drawing object "+obj.getId());

            obj.draw(g, panel);
        }

    }

    public void updateId() {

        this.idCurrentPoint = 1;
        this.idCurrentNode = 1;
        this.idCurrentElement = 1;



        for (int i = 0; i < this.objects.size(); i++) {

            IPFEM2DDrawableObject obj = this.objects.get(i);

            if (obj instanceof IPFEM2DMeshableObject) {

                PFEM2DNode[] nodes = ((IPFEM2DMeshableObject) obj).getNodes();

                if (nodes != null) {

                    for (int j = 0; j < nodes.length; j++) {
                        if (nodes[j].getNumId()>this.idCurrentNode) {
                            this.idCurrentNode=nodes[j].getNumId();
                        }
                    }
                }
                
                IPFEM2DElement[] elements=((IPFEM2DMeshableObject) obj).getElements();
                
                if (elements!=null) {
                    
                    for (int j = 0; j < elements.length; j++) {
                        
                        if (elements[j].getNumId()>this.idCurrentElement) {
                            this.idCurrentElement=elements[j].getNumId();
                        }
                    }
                }
                
            }

        }


    }
    private ArrayList<IPFEM2DDrawableObject> objects;
    private long idCurrentNode;
    private long idCurrentPoint;
    private long idCurrentElement;

    public long getIdCurrentElement() {
        idCurrentElement++;
        return idCurrentElement;
    }

    public long getIdCurrentNode() {
        idCurrentNode++;
        return idCurrentNode;
    }
    
    public void incrementIdCurrentElement() {
        idCurrentElement++;
    }
    
    public void incrementIdCurrentNode() {
        idCurrentNode++;
    }
    
    
}
