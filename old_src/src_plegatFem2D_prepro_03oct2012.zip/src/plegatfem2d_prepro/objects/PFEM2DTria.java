/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Iterator;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author JMB
 */
public class PFEM2DTria implements IPFEM2DDrawableObject, IPFEM2DElement {

    private PFEM2DNode nd1, nd2, nd3;
    private long id;
    private double modulus, thickness;
    private boolean visible;
    private PFEM2DPoint centre;
    private double radius;
    private IPFEM2DElement[] neighbours = new IPFEM2DElement[3];

    public PFEM2DTria(long id, PFEM2DNode nd1, PFEM2DNode nd2, PFEM2DNode nd3, double modulus, double thickness) {
        this.nd1 = nd1;
        this.nd2 = nd2;
        this.nd3 = nd3;
        this.id = id;
        this.modulus = modulus;
        this.thickness = thickness;

        this.visible = true;
        this.initNeighbours();

        this.defCentre();
    }

    public final void initNeighbours() {
        for (int i = 0; i < neighbours.length; i++) {
            this.neighbours[i] = null;

        }
    }

    public final void defCentre() {

        double xab = nd2.getX() - nd1.getX();
        double xca = nd1.getX() - nd3.getX();

        double yab = nd2.getY() - nd1.getY();
        double yca = nd1.getY() - nd3.getY();

        double normeAB = xab * xab + yab * yab;
        double normeCA = xca * xca + yca * yca;

        xab /= normeAB;
        yab /= normeAB;
        xca /= normeCA;
        yca /= normeCA;

        double xd = (nd1.getX() + nd2.getX()) / 2.0;
        double yd = (nd1.getY() + nd2.getY()) / 2.0;
        double xf = (nd1.getX() + nd3.getX()) / 2.0;
        double yf = (nd1.getY() + nd3.getY()) / 2.0;

        double alpha, beta;

        if (Math.abs(yab) < 1e-5) {
            beta = (xd - xf) / yca;
            alpha = (yd - yf + beta * xca) / xab;
        } else {
            beta = (yd - yf - (xf - xd) * xab / yab) / (yca * xab / yab - xca);
            alpha = (xf - xd + beta * yca) / yab;
        }

        this.centre = new PFEM2DPoint(0, xd + alpha * yab, yd - alpha * xab);
        this.radius = this.nd1.getDistanceTo(this.centre);

        /*
         System.out.println("triangle " + this.getId());
         System.out.println("radius1=" + this.nd1.getDistanceTo(this.centre));
         System.out.println("radius2=" + this.nd2.getDistanceTo(this.centre));
         System.out.println("radius2=" + this.nd3.getDistanceTo(this.centre));
         */

    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {

        if (this.isVisible()) {
            int xloc1 = panel.getLocalCoordX(this.nd1.getX());
            int yloc1 = panel.getLocalCoordY(this.nd1.getY());

            int xloc2 = panel.getLocalCoordX(this.nd2.getX());
            int yloc2 = panel.getLocalCoordY(this.nd2.getY());

            int xloc3 = panel.getLocalCoordX(this.nd3.getX());
            int yloc3 = panel.getLocalCoordY(this.nd3.getY());

            int xlocC = (xloc1 + xloc2 + xloc3) / 3;
            int ylocC = (yloc1 + yloc2 + yloc3) / 3;

            double coef = 0.85;

            xloc1 = (int) Math.round(xlocC + coef * (xloc1 - xlocC));
            yloc1 = (int) Math.round(ylocC + coef * (yloc1 - ylocC));

            xloc2 = (int) Math.round(xlocC + coef * (xloc2 - xlocC));
            yloc2 = (int) Math.round(ylocC + coef * (yloc2 - ylocC));

            xloc3 = (int) Math.round(xlocC + coef * (xloc3 - xlocC));
            yloc3 = (int) Math.round(ylocC + coef * (yloc3 - ylocC));



            g.setColor(Color.cyan);
            g.drawLine(xloc1, yloc1, xloc2, yloc2);
            g.drawLine(xloc2, yloc2, xloc3, yloc3);
            g.drawLine(xloc3, yloc3, xloc1, yloc1);

            //dessin cercle circonscrit

            /*
             for (int i = 0; i < 36; i++) {

             int xcirc1 = panel.getLocalCoordX(this.centre.getX()+this.radius*Math.cos(i*Math.PI/18.));
             int ycirc1 = panel.getLocalCoordY(this.centre.getY()+this.radius*Math.sin(i*Math.PI/18.));

             int xcirc2 = panel.getLocalCoordX(this.centre.getX()+this.radius*Math.cos((i+1)*Math.PI/18.));
             int ycirc2 = panel.getLocalCoordY(this.centre.getY()+this.radius*Math.sin((i+1)*Math.PI/18.));

             g.setColor(Color.PINK);
             g.drawLine(xcirc1, ycirc1, xcirc2, ycirc2);
             }
             */

            //dessin id

            g.drawString("T" + this.id, xlocC, ylocC);

        }


    }

    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Tria " + this.id;
    }

    @Override
    public long getNumId() {
        return this.id;
    }

    @Override
    public PFEM2DNode[] getNodes() {

        PFEM2DNode[] tempArray = new PFEM2DNode[3];
        tempArray[0] = this.nd1;
        tempArray[1] = this.nd2;
        tempArray[2] = this.nd3;

        return tempArray;
    }

    @Override
    public PFEM2DNode getNode(int rank) {

        if (rank == 0) {
            return this.nd1;
        } else if (rank == 1) {
            return this.nd2;
        } else if (rank == 2) {
            return this.nd3;
        } else {
            return null;
        }


    }

    public boolean isInCircle(PFEM2DNode node) {

        if (node.getDistanceTo(this.centre) <= (this.radius + 1e-8)) {
            return true;
        } else {
            return false;
        }

    }

    public double[] getLocalCoordinate(PFEM2DNode node) {
        return getLocalCoordinate(this.nd1, this.nd2, this.nd3, node);
    }

    public static double[] getLocalCoordinate(PFEM2DNode origin, PFEM2DNode xAxis, PFEM2DNode yAxis, PFEM2DNode node) {

        double epsilon = 1e-5;

        double xa = origin.getX();
        double ya = origin.getY();

        double xb = xAxis.getX();
        double yb = xAxis.getY();

        double xc = yAxis.getX();
        double yc = yAxis.getY();

        double xm = node.getX();
        double ym = node.getY();

        double[] lambda = new double[2];


        if (Math.abs(xb - xa) < epsilon) {
            lambda[1] = (xm - xa) / (xc - xa);
        } else {
            lambda[1] = ((yc - ya) * (xb - xa) - (xc - xa) * (yb - ya)) / ((ym - ya) * (xb - xa) - (xm - xa) * (yb - ya));
        }
        lambda[0] = ((ym - ya) - lambda[1] * (yc - ya)) / (yb - ya);

        return lambda;
    }

    public static int getNodeRelativePosition(PFEM2DNode origin, PFEM2DNode xAxis, PFEM2DNode yAxis, PFEM2DNode node) {

        double epsilon = 1e-5;

        double[] lambda = getLocalCoordinate(origin, xAxis, yAxis, node);

        int local = 0;

        if (Math.abs(lambda[0]) < epsilon) {
            if (lambda[1] > 0) {
                if (lambda[0] + lambda[1] > 1) {
                    local = 13;
                } else {
                    local = 10;
                }
            } else if (lambda[1] < 0) {
                local = 16;
            }
        } else if (lambda[0] > 0) {
            if (Math.abs(lambda[1]) < epsilon) {
                if (lambda[0] + lambda[1] > 1) {
                    local = 12;
                } else {
                    local = 8;
                }
            } else if (lambda[1] > 0) {
                if (Math.abs(lambda[0] + lambda[1] - 1) < epsilon) {
                    local = 9;
                } else if (lambda[0] + lambda[1] > 1) {
                    local = 4;
                } else {
                    local = 1;
                }
            } else if (lambda[1] < 0) {
                if (Math.abs(lambda[0] + lambda[1] - 1) < epsilon) {
                    local = 11;
                } else if (lambda[0] + lambda[1] > 1) {
                    local = 3;
                } else {
                    local = 2;
                }
            }
        } else if (lambda[0] < 0) {
            if (Math.abs(lambda[1]) < epsilon) {

                local = 15;

            } else if (lambda[1] > 0) {
                if (Math.abs(lambda[0] + lambda[1] - 1) < epsilon) {
                    local = 14;
                } else if (lambda[0] + lambda[1] > 1) {
                    local = 5;
                } else {
                    local = 6;
                }
            } else if (lambda[1] < 0) {

                local = 7;

            }
        }

        return local;

    }

    public int getNodeRelativePosition(PFEM2DNode node) {
        return getNodeRelativePosition(this.nd1, this.nd2, this.nd3, node);
    }

    public boolean isNodeIntersectingOppositeEdge(PFEM2DNode nodeTria, PFEM2DNode node) {

        int local = this.getNodeRelativePosition(node);

        if ((nodeTria == nd1) && (local == 4)) {
            return true;
        }
        if ((nodeTria == nd2) && (local == 6)) {
            return true;
        }
        if ((nodeTria == nd3) && (local == 2)) {
            return true;
        }

        return false;

    }

    public int isEdgeIntersecting(PFEM2DEdge edge) {

        PFEM2DPoint pt1 = edge.getIntersection(nd1, nd2);
        PFEM2DPoint pt2 = edge.getIntersection(nd2, nd3);
        PFEM2DPoint pt3 = edge.getIntersection(nd3, nd1);

        int val = 0;

        if (pt1 != null) {
            val = val + 1;
        }
        if (pt2 != null) {
            val = val + 2;
        }
        if (pt3 != null) {
            val = val + 4;
        }

        return val;

    }

    public void findNeighbours() {

        for (int i = 0; i < 3; i++) {

            PFEM2DEdge edge;


            if (i == 0) {
                edge = new PFEM2DEdge(0, nd2, nd3);
            } else if (i == 1) {
                edge = new PFEM2DEdge(0, nd3, nd1);
            } else {
                edge = new PFEM2DEdge(0, nd1, nd2);
            }

            edge.findConnectedElements();

            IPFEM2DElement[] connected = edge.getConnectedElements();

            if (connected[0] == this) {
                this.neighbours[i] = connected[1];
            } else if (connected[1] == this) {
                this.neighbours[i] = connected[0];
            } else {
                this.neighbours[i] = null;
            }

            System.out.println("adding neighbour " + (this.neighbours[i] != null ? this.neighbours[i].getId() : "null") + " to element " + this.getId());

        }




    }

    public IPFEM2DElement getNeighbours(int node) {
        return this.neighbours[node];
    }

    public IPFEM2DElement getNeighbours(PFEM2DNode node) {

        if (node == this.nd1) {
            return this.neighbours[0];
        } else if (node == this.nd2) {
            return this.neighbours[1];
        } else if (node == this.nd3) {
            return this.neighbours[2];
        } else {
            return null;
        }


    }

    public boolean isElementEdge(PFEM2DEdge edge) {

        PFEM2DNode nodEdge1 = edge.getNode(0);
        PFEM2DNode nodEdge2 = edge.getNode(1);

        boolean flag = true;

        flag = flag && ((nodEdge1 == this.nd1) || (nodEdge1 == this.nd2) || (nodEdge1 == this.nd3));
        flag = flag && ((nodEdge2 == this.nd1) || (nodEdge2 == this.nd2) || (nodEdge2 == this.nd3));

        return flag;

    }

    public int getNodeVertexRank(PFEM2DNode node) {

        if (node == this.nd1) {
            return 0;
        } else if (node == this.nd2) {
            return 1;
        } else if (node == this.nd3) {
            return 2;
        } else {
            return -1;
        }

    }

    public boolean swapDiagonal(PFEM2DTria tria) {

        PFEM2DNode[] thisNodes = this.getNodes();
        PFEM2DNode[] triaNodes = tria.getNodes();

        /*
         for (int i = 0; i < 3; i++) {
         System.out.println(" thisNode[" + i + "]=" + thisNodes[i].getId());
         }
         for (int i = 0; i < 3; i++) {
         System.out.println(" triaNode[" + i + "]=" + triaNodes[i].getId());
         }
         */

        System.out.println("before swap:");
        System.out.println("    T" + this.getId() + ": " + this.nd1.getId() + ", " + this.nd2.getId() + ", " + this.nd3.getId());
        System.out.println("    T" + tria.getId() + ": " + tria.nd1.getId() + ", " + tria.nd2.getId() + ", " + tria.nd3.getId());

        /*
         System.out.println("voisinage:");
         System.out.println("  this 0:" + (this.neighbours[0] == null ? "null" : this.neighbours[0].getId()));
         System.out.println("  this 1:" + (this.neighbours[1] == null ? "null" : this.neighbours[1].getId()));
         System.out.println("  this 2:" + (this.neighbours[2] == null ? "null" : this.neighbours[2].getId()));
         System.out.println("  tria 0:" + (tria.neighbours[0] == null ? "null" : tria.neighbours[0].getId()));
         System.out.println("  tria 1:" + (tria.neighbours[1] == null ? "null" : tria.neighbours[1].getId()));
         System.out.println("  tria 2:" + (tria.neighbours[2] == null ? "null" : tria.neighbours[2].getId()));
         */

        int diag1 = -1;
        int diag2 = -1;

        for (int i = 0; i < 3; i++) {
            if (tria == this.neighbours[i]) {
                diag1 = i;
            }
            if (this == tria.neighbours[i]) {
                diag2 = i;
            }
        }

        if ((diag1 != -1) && (diag2 != -1)) {

            int rank2 = getNodeRelativePosition(thisNodes[diag1],
                    thisNodes[(diag1 + 1) % 3], thisNodes[(diag1 + 2) % 3],
                    triaNodes[diag2]);

            System.out.println("base node: " + thisNodes[diag1].getId() + ", target node: " + triaNodes[diag2].getId());

            System.out.println("rank2=" + rank2);

            if (rank2 == 4) {

                PFEM2DNode diagNode1 = thisNodes[diag1];
                PFEM2DNode diagNode2 = triaNodes[diag2];
                PFEM2DNode remain1 = thisNodes[(diag1 + 1) % 3];
                PFEM2DNode remain2 = thisNodes[(diag1 + 2) % 3];

                /*
                 System.out.println("diag1=" + diag1);
                 System.out.println("(diag1+1)%3=" + (diag1 + 1) % 3);
                 System.out.println("(diag1+2)%3=" + (diag1 + 2) % 3);

                 System.out.println("diagNode1: " + diagNode1.getId());
                 System.out.println("diagNode2: " + diagNode2.getId());
                 System.out.println("remain1: " + remain1.getId());
                 System.out.println("remain2: " + remain2.getId());
                 */

                // mise à jour des connectivités

                this.nd1 = diagNode1;
                this.nd2 = remain1;
                this.nd3 = diagNode2;

                tria.nd1 = diagNode2;
                tria.nd2 = remain2;
                tria.nd3 = diagNode1;

                // mise à jour des voisins

                System.out.println("after swap:");
                System.out.println("    T" + this.getId() + ": " + this.nd1.getId() + ", " + this.nd2.getId() + ", " + this.nd3.getId());
                System.out.println("    T" + tria.getId() + ": " + tria.nd1.getId() + ", " + tria.nd2.getId() + ", " + tria.nd3.getId());



                this.nd2.removeConnectedElement(tria);
                this.nd2.removeConnectedElement(this);
                tria.nd2.removeConnectedElement(tria);
                tria.nd2.removeConnectedElement(this);

                this.nd1.addConnectedElement(tria);
                tria.nd1.addConnectedElement(this);

                this.nd2.addConnectedElement(this);
                tria.nd2.addConnectedElement(tria);


                this.findNeighbours();
                tria.findNeighbours();

                return true;

            }


        }

        return false;
    }
}
