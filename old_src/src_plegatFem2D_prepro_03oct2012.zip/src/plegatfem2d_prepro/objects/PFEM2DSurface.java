/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import plegatfem2d_prepro.PFEM2DObjectManager;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author jmb2
 */
public class PFEM2DSurface implements IPFEM2DDrawableObject, IPFEM2DMeshableObject {

    private ArrayList<IPFEM2DDrawableObject> objects;
    private boolean visible;
    private long id;
    private boolean meshed;
    private ArrayList<PFEM2DNode> nodes;
    private ArrayList<IPFEM2DElement> elements;
    private double elementMaxSize = 10;
    private double modulus, thickness;
    private int meshMethod = IPFEM2DMeshableObject.DELAUNAY;

    public PFEM2DSurface() {
        this.objects = new ArrayList<IPFEM2DDrawableObject>();

        this.meshed = false;
        this.nodes = new ArrayList<PFEM2DNode>();
        this.elements = new ArrayList<IPFEM2DElement>();

    }

    public void add(IPFEM2DDrawableObject obj) {
        this.objects.add(obj);
    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {
        for (int i = 0; i < this.objects.size(); i++) {

            IPFEM2DDrawableObject obj = this.objects.get(i);

            obj.draw(g, panel);
        }

        if (this.isMeshed()) {
            this.drawMesh(g, panel);
        }
    }

    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Surface " + this.id;
    }

    public void mesh(PFEM2DObjectManager pom) {

        this.deleteMesh();

        if (!this.meshed) {

            for (int i = 0; i < this.objects.size(); i++) {

                IPFEM2DDrawableObject obj = this.objects.get(i);

                if (obj instanceof IPFEM2DMeshableObject) {

                    if (!((IPFEM2DMeshableObject) obj).isMeshed()) {
                        ((IPFEM2DMeshableObject) obj).mesh(pom);
                    }


                }
            }

            if (this.meshMethod == IPFEM2DMeshableObject.DELAUNAY) {
                this.meshDelaunay(pom);
            }

        }


    }

    @Override
    public void setMeshMethod(int method) {
        this.meshMethod = method;
    }

    @Override
    public void deleteMesh() {
        this.meshed = false;
        this.nodes.clear();
        this.elements.clear();
    }

    @Override
    public boolean isMeshed() {
        return this.meshed;
    }

    @Override
    public PFEM2DNode[] getNodes() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public IPFEM2DElement[] getElements() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void drawMesh(Graphics g, PFem2DGuiPanel panel) {

        for (int i = 0; i < this.objects.size(); i++) {

            IPFEM2DDrawableObject obj = this.objects.get(i);

            if (obj instanceof IPFEM2DMeshableObject) {

                ((IPFEM2DMeshableObject) obj).drawMesh(g, panel);

            }
        }

        for (int i = 0; i < this.elements.size(); i++) {

            this.elements.get(i).draw(g, panel);

        }



    }

    public void meshDelaunay(PFEM2DObjectManager pom) {

        ArrayList<PFEM2DNode> boundaryNodes = new ArrayList<PFEM2DNode>();

        // recuperation des noeuds de la frontiere

        for (int i = 0; i < this.objects.size(); i++) {

            IPFEM2DDrawableObject obj = this.objects.get(i);

            if (obj instanceof IPFEM2DMeshableObject) {

                PFEM2DNode[] temp = ((IPFEM2DMeshableObject) obj).getNodes();

                System.out.println("adding nodes from object: " + obj.getId() + ", nb nodes: " + temp.length);

                boundaryNodes.addAll(Arrays.asList(temp));

            }
        }

        double xmin, xmax, ymin, ymax;
        xmin = Double.MAX_VALUE;
        ymin = Double.MAX_VALUE;
        xmax = Double.MIN_VALUE;
        ymax = Double.MIN_VALUE;


        // definition de la bounding box

        for (int i = 0; i < boundaryNodes.size(); i++) {

            PFEM2DNode node = boundaryNodes.get(i);

            double x = node.getX();
            double y = node.getY();

            if (x > xmax) {
                xmax = x;
            } else if (x < xmin) {
                xmin = x;
            }

            if (y > ymax) {
                ymax = y;
            } else if (y < ymin) {
                ymin = y;
            }

        }

        System.out.println("bornes: x/" + xmin + "/" + xmax + ", y/" + ymin + "/" + ymax);

        int deltaBox = 20;

        PFEM2DNode nd1 = new PFEM2DNode(1, xmin - deltaBox, ymin - deltaBox);
        PFEM2DNode nd2 = new PFEM2DNode(2, xmax + deltaBox, ymin - deltaBox);
        PFEM2DNode nd3 = new PFEM2DNode(3, xmax + deltaBox, ymax + deltaBox);
        PFEM2DNode nd4 = new PFEM2DNode(4, xmin - deltaBox, ymax + deltaBox);

        this.nodes.add(nd1);
        this.nodes.add(nd2);
        this.nodes.add(nd3);
        this.nodes.add(nd4);

        this.elements.add(new PFEM2DTria(0, nd1, nd2, nd3, 1, 1));
        this.elements.add(new PFEM2DTria(0, nd1, nd3, nd4, 1, 1));

        long idElement = pom.getIdCurrentElement() + 1;


        // insertion des noeuds suivant algo de delaunay

        ArrayList<PFEM2DTria> trias2remove = new ArrayList<PFEM2DTria>();

        for (int i = 0; i < boundaryNodes.size(); i++) {
            //for (int i = 0; i < 69; i++) {

            PFEM2DNode node = boundaryNodes.get(i);

            trias2remove.clear();

            for (int j = 0; j < this.elements.size(); j++) {

                PFEM2DTria tria = (PFEM2DTria) this.elements.get(j);

                if (tria.isInCircle(node)) {
                    trias2remove.add(tria);
                }
            }

            ArrayList<NodeCouple> couples = new ArrayList<NodeCouple>();

            for (int j = 0; j < trias2remove.size(); j++) {
                this.elements.remove(trias2remove.get(j));

                PFEM2DNode[] triaNodes = trias2remove.get(j).getNodes();

                couples.add(new NodeCouple(triaNodes[0], triaNodes[1]));
                couples.add(new NodeCouple(triaNodes[1], triaNodes[2]));
                couples.add(new NodeCouple(triaNodes[2], triaNodes[0]));
            }

            //nettoyage des couples

            for (int j = couples.size() - 1; j >= 0; j--) {

                NodeCouple nc = couples.get(j);

                for (int k = couples.size() - 1; k > j; k--) {

                    NodeCouple nc2 = couples.get(k);

                    if (nc2.isEqual(nc)) {
                        System.out.println("removing couple " + nc2.toString());
                        couples.remove(k);
                        couples.remove(j);
                        break;
                    }


                }

            }

            //creation des nouveaux trias

            couples.trimToSize();

            for (int j = 0; j < couples.size(); j++) {

                NodeCouple nc = couples.get(j);

                this.elements.add(new PFEM2DTria(pom.getIdCurrentElement(), node, nc.getNd1(), nc.getNd2(), 1, 1));

            }



        }


        // connectivités noeuds/edges/elements

        System.out.println("initialisation des connectivités des noeuds...");

        for (Iterator<IPFEM2DElement> it = this.elements.iterator(); it.hasNext();) {
            PFEM2DTria element = (PFEM2DTria) it.next();

            PFEM2DNode[] elementNodes = element.getNodes();

            for (PFEM2DNode pFEM2DNode : elementNodes) {
                pFEM2DNode.addConnectedElement(element);
            }


        }




        System.out.println("initialisation des connectivités des trias...");

        for (Iterator<IPFEM2DElement> it = this.elements.iterator(); it.hasNext();) {
            PFEM2DTria element = (PFEM2DTria) it.next();
            element.findNeighbours();
        }


        // recuperation des edges de la frontiere

        System.out.println("récupération des edges de la frontière...");

        ArrayList<PFEM2DEdge> listEdge = new ArrayList<PFEM2DEdge>();

        for (Iterator<IPFEM2DDrawableObject> it = this.objects.iterator(); it.hasNext();) {
            IPFEM2DDrawableObject pFEM2DEdge = it.next();

            if (pFEM2DEdge instanceof IPFEM2DCurve) {
                listEdge.addAll(((IPFEM2DCurve) pFEM2DEdge).getEdges());
            }

        }

        listEdge.trimToSize();


        // respect de la frontiere

        System.out.println("lancement respect de la frontière...");

        //for (Iterator<PFEM2DEdge> it = listEdge.iterator(); it.hasNext()&&false;) {
        for (Iterator<PFEM2DEdge> it = listEdge.iterator(); it.hasNext();) {
            PFEM2DEdge edge = it.next();

            boolean flag_verbose = false;

            if (edge.toString().equals("Edge_Node 1_Node 2")) {
                flag_verbose = true;
            }


            PFEM2DNode nodEdge1 = edge.getNode(0);
            PFEM2DNode nodEdge2 = edge.getNode(1);

            System.out.println("edge: " + edge.toString());

            ArrayList<IPFEM2DElement> trias1 = nodEdge1.getConnectedElements();
            ArrayList<IPFEM2DElement> trias2 = nodEdge2.getConnectedElements();

            // vérification edge élément

            boolean flag_edge_element = false;

            for (Iterator<IPFEM2DElement> it1 = trias1.iterator(); it1.hasNext() && !flag_edge_element;) {
                PFEM2DTria iPFEM2DElement = (PFEM2DTria) it1.next();

                flag_edge_element = flag_edge_element || iPFEM2DElement.isElementEdge(edge);

                if (flag_edge_element) {
                    System.out.println(edge.toString() + " is edge for element " + iPFEM2DElement.getId());
                }
            }


            // recherche des éléments intersectés par l'edge

            if (!flag_edge_element) {
                ArrayList<PFEM2DTria> listeElements = new ArrayList<PFEM2DTria>();

                for (Iterator<IPFEM2DElement> it1 = trias1.iterator(); it1.hasNext();) {
                    PFEM2DTria pFEM2DTria = (PFEM2DTria) it1.next();

                    if (flag_verbose) {
                        System.out.println("tria " + pFEM2DTria.getId());

                        PFEM2DPoint pt1 = edge.getIntersection(nd1, nd2);
                        PFEM2DPoint pt2 = edge.getIntersection(nd2, nd3);
                        PFEM2DPoint pt3 = edge.getIntersection(nd3, nd1);

                        if (pt1 == null) {
                            System.out.println("pt1 null");
                        } else {
                            System.out.println("pt1: " + pt1.toString());
                        }

                        if (pt1 == null) {
                            System.out.println("pt2 null");
                        } else {
                            System.out.println("pt2: " + pt2.toString());
                        }

                        if (pt3 == null) {
                            System.out.println("pt3 null");
                        } else {
                            System.out.println("pt3: " + pt3.toString());
                        }

                    }

                    if (pFEM2DTria.isEdgeIntersecting(edge) > 0) {
                        listeElements.add(pFEM2DTria);
                        System.out.println("adding from 1st node base element " + pFEM2DTria.getId() + " to edge " + edge.toString() + " calculation");
                    }

                }

                for (Iterator<IPFEM2DElement> it1 = trias2.iterator(); it1.hasNext();) {
                    PFEM2DTria pFEM2DTria = (PFEM2DTria) it1.next();

                    System.out.println("checking "+pFEM2DTria.getId());
                    
                    if (pFEM2DTria.isEdgeIntersecting(edge) > 0) {

                        int rank = listeElements.indexOf(pFEM2DTria);

                        if (rank == -1) {
                            listeElements.add(pFEM2DTria);
                            System.out.println("adding from 2nd node base element " + pFEM2DTria.getId() + " to edge " + edge.toString() + " calculation");
                        }
                    }

                }

                int rank = 0;

                //while (rank < listeElements.size()) {
                while ((rank < listeElements.size()) && (rank < 2)) {

                    PFEM2DTria tria = listeElements.get(rank);

                    for (int i = 0; i < 3; i++) {
                        PFEM2DTria neig = (PFEM2DTria) tria.getNeighbours(i);

                        if ((neig != null) && (neig.isEdgeIntersecting(edge) > 0)&&(listeElements.indexOf(neig)==-1)) {
                            listeElements.add(neig);
                            System.out.println("adding element " + neig.getId() + " to edge " + edge.toString() + " calculation");
                        }
                    }


                    rank++;
                }

            }

        }




        // fin du maillage

        System.out.println("delaunay meshing finished");
        this.meshed = true;

    }
}
