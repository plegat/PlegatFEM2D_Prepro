/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author JMB
 */
public class PFEM2DLoopLine implements IPFEM2DDrawableObject, IPFEM2DMeshableObject {
    
    private ArrayList<IPFEM2DDrawableObject> objects;
    private boolean visible;
    private long id;
    
    public PFEM2DLoopLine() {
        this.objects = new ArrayList<IPFEM2DDrawableObject>();
        
    }
    
    public void add(IPFEM2DDrawableObject obj) {
        this.objects.add(obj);
    }
    
    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }
    
    @Override
    public boolean isVisible() {
        return this.visible;
    }
    
    @Override
    public String getId() {
        return "LoopLine " + this.id;
    }
    
    @Override
    public void mesh() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    @Override
    public void setMeshMethod(int method) {
        
        for (int i = 0; i < this.objects.size(); i++) {
            
            if (this.objects.get(i) instanceof IPFEM2DMeshableObject) {
                ((IPFEM2DMeshableObject) this.objects.get(i)).setMeshMethod(method);
            }
        }
        
    }
    
    @Override
    public void deleteMesh() {
        for (int i = 0; i < this.objects.size(); i++) {
            
            if (this.objects.get(i) instanceof IPFEM2DMeshableObject) {
                ((IPFEM2DMeshableObject) this.objects.get(i)).deleteMesh();
            }
        }
    }
    
    @Override
    public boolean isMeshed() {
        
        boolean flag=true;
        
        for (int i = 0; i < this.objects.size(); i++) {
            
            if (this.objects.get(i) instanceof IPFEM2DMeshableObject) {
                flag=flag && ((IPFEM2DMeshableObject) this.objects.get(i)).isMeshed();
            }
        }
        
        return flag;
    }
    
    @Override
    public PFEM2DNode[] getNodes() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    @Override
    public IPFEM2DElement[] getElements() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
