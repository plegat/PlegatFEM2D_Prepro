/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

/**
 *
 * @author jmb2
 */
public interface IPFEM2DMeshableObject {
    
    public void mesh();
    
    public void setMeshMethod(int method);

    public void deleteMesh();
    
    public boolean isMeshed();
    
    public PFEM2DNode[] getNodes();
    public IPFEM2DElement[] getElements();
    
    public static int DELAUNAY=1;
    public static int FRONT=2;
   
    public static int NODE_ONLY=3;
    public static int NODE_AND_BEAM=4;
            
            
}
