/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Color;
import java.awt.Graphics;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author jmb2
 */
public class PFEM2DNode implements IPFEM2DDrawableObject {

    private double x, y;
    private long id;
    private boolean visible;

    public PFEM2DNode(long id, double x, double y) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.visible = false;
    }

    public PFEM2DNode() {
    }

    public void setId(long id) {
        this.id = id;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {

        if (this.isVisible()) {
            int xloc = panel.getLocalCoordX(this.x);
            int yloc = panel.getLocalCoordY(this.y);

            int[] xPoints = {xloc + 5, xloc, xloc - 5, xloc, xloc + 5};
            int[] yPoints = {yloc, yloc + 5, yloc, yloc - 5, yloc};


            g.setColor(Color.red);
            g.drawPolyline(xPoints, yPoints, 5);
        }

    }

    @Override
    public void setVisible(boolean flag) {
        this.visible = flag;
    }

    @Override
    public boolean isVisible() {
        return this.visible;
    }

    @Override
    public String getId() {
        return "Node " + this.id;
    }
    
    public long getNumId() {
        return this.id;
    }
    
    public double getDistanceTo(PFEM2DPoint pt) {
        return Math.sqrt(Math.pow(pt.getX()-this.getX(),2)+Math.pow(pt.getY()-this.getY(),2));
    }
    
    public double getDistanceTo(PFEM2DNode nd) {
        return Math.sqrt(Math.pow(nd.getX()-this.getX(),2)+Math.pow(nd.getY()-this.getY(),2));
    }
    
    
    public PFEM2DNode getInterpolated(PFEM2DNode nd2,double coef) {
        
        double xInt=this.x+(nd2.x-this.x)*coef;
        double yInt=this.y+(nd2.y-this.y)*coef;
        
        return new PFEM2DNode(0, xInt, yInt);
        
        
    }
    
    public PFEM2DNode getRotated(PFEM2DPoint centre,double angle) {
        
        double dx=this.getX()-centre.getX();
        double dy=this.getY()-centre.getY();
        
        double angleBase=Math.atan2(dy, dx);
        double radius=this.getDistanceTo(centre);
        
        double xRot=centre.getX()+radius*Math.cos(angleBase+angle/180.*Math.PI);
        double yRot=centre.getY()+radius*Math.sin(angleBase+angle/180.*Math.PI);
        
        return new PFEM2DNode(0, xRot, yRot);
        
        
    }
}
