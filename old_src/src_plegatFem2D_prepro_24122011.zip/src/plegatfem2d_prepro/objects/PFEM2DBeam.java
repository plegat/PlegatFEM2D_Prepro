/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro.objects;

import java.awt.Graphics;
import plegatfem2d_prepro.PFem2DGuiPanel;

/**
 *
 * @author JMB
 */
public class PFEM2DBeam implements IPFEM2DDrawableObject,IPFEM2DElement {

    private PFEM2DNode nd1,nd2;
    private long id;
    private double modulus, area, inertia;

    public PFEM2DBeam(long id, PFEM2DNode nd1, PFEM2DNode nd2, double modulus, double area, double inertia) {
        this.nd1 = nd1;
        this.nd2 = nd2;
        this.id = id;
        this.modulus = modulus;
        this.area = area;
        this.inertia = inertia;
    }
    
    
    
    @Override
    public void draw(Graphics g, PFem2DGuiPanel panel) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void setVisible(boolean flag) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean isVisible() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String getId() {
        return "Beam " + this.id;
    }
    
    public long getNumId() {
        return this.id;
    }
    
    
    
}
