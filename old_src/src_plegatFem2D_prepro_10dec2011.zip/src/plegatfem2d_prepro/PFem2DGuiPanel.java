/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import javax.swing.JPanel;

/**
 *
 * @author jmb2
 */
public class PFem2DGuiPanel extends JPanel implements MouseListener, MouseMotionListener {

    public PFem2DGuiPanel() {
        super();


        this.mode = VIEW;

        this.offsetX = 0;
        this.offsetY = 0;
        
        this.echelle=100;
        this.drawingEchelle=100;

        this.addMouseListener(this);
        this.addMouseMotionListener(this);
    }
    private int xold, yold;
    private int mode;
    private static int VIEW = 0;
    private static int DRAG = 1;
    private static int SCALE = 2;
    private int offsetX, offsetY;
    private double echelle;
    private double drawingEchelle;
    

    @Override
    public void paintComponent(Graphics g) {

        Graphics2D g2 = (Graphics2D) g;


        int h = this.getHeight();
        int w = this.getWidth();



        g.setColor(Color.BLACK);
        g.fillRect(0, 0, w, h);

        //tracé des axes et du quadrillage

        g.setColor(Color.GREEN);
        g.drawLine(w / 2 + this.offsetX, 0, w / 2 + this.offsetX, h);
        g.drawLine(0, h / 2 + this.offsetY, w, h / 2 + this.offsetY);

        int offsetStrokeX=7-this.offsetX % 7;
        int offsetStrokeY=7-this.offsetY % 7;
        
        float[] dash = {2, 5};
        BasicStroke bsX = new BasicStroke(1, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND, 10, dash, offsetStrokeX);
        BasicStroke bsY = new BasicStroke(1, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_ROUND, 10, dash, offsetStrokeY);
        
        g2.setStroke(bsY);

        int nbxp=(w-(w/2+this.offsetX))/(int)Math.round(this.echelle)+1;
        int nbxm=(w/2+this.offsetX)/(int)Math.round(this.echelle)+1;
        
        
        for (int i = 1; i < nbxp; i++) {
            int xline=w/2+this.offsetX+i*(int)Math.round(this.echelle);
            g.drawLine(xline, 0, xline, h);

        }
        for (int i = 1; i < nbxm; i++) {
            int xline=w/2+this.offsetX-i*(int)Math.round(this.echelle);
            g.drawLine(xline, 0, xline, h);

        }
        
        g2.setStroke(bsX);

        int nbym=(h-(h/2+this.offsetY))/(int)Math.round(this.echelle)+1;
        int nbyp=(h/2+this.offsetY)/(int)Math.round(this.echelle)+1;
        
        
        for (int i = 1; i < nbyp; i++) {
            int yline=h/2+this.offsetY-i*(int)Math.round(this.echelle);
            g.drawLine(0, yline, w, yline);
        }
        for (int i = 1; i < nbym; i++) {
            int yline=h/2+this.offsetY+i*(int)Math.round(this.echelle);
            g.drawLine(0, yline, w, yline);
        }


        g.setColor(Color.red);
        g2.setStroke(new BasicStroke());
        
        g.drawRect(w/2+this.offsetX+(int)Math.round(100/100.*this.echelle)-5, h/2+this.offsetY-(int)Math.round(100/100.*this.echelle)-5, 10, 10);
        
        
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (this.mode == DRAG) {
            int x = e.getX();
            int y = e.getY();

            this.offsetX = this.offsetX + (x - this.xold);
            this.offsetY = this.offsetY + (y - this.yold);

            this.xold = x;
            this.yold = y;

            this.repaint();
        } else if (this.mode == SCALE) {
            int x = e.getX();
            int y = e.getY();

            int dx=x-this.xold;
            int dy=y-this.yold;
            
            int delta=0;
            if (Math.abs(dx)>Math.abs(dy)) {
                delta=dx;
            } else {
                delta=dy;
            }
            
            this.xold = x;
            this.yold = y;
            
            this.echelle=Math.max(1, this.echelle+delta);
            
            //long fact=Math.round(echelle/400.);
            
            this.drawingEchelle=100+((this.echelle-100) % 200);
            
            
            
            System.out.println("echelle:         "+this.echelle);
            System.out.println("drawing echelle: "+this.drawingEchelle);
            
            this.repaint();
            
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {

        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        this.xold = e.getX();
        this.yold = e.getY();

        if (e.getButton()==MouseEvent.BUTTON1) {
            this.mode = DRAG;
        } else if (e.getButton()==MouseEvent.BUTTON2) {
            this.mode = SCALE;
        } else {
            this.mode = VIEW;
        }
        
        
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        this.mode = VIEW;
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
