/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package plegatfem2d_prepro;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JSeparator;
import javax.swing.JToolBar;

/**
 *
 * @author jmb2
 */
public class PlegatFem2D_Prepro extends JFrame {

    public PlegatFem2D_Prepro(String frameTitle) {
        super(frameTitle);
        
        this.initComponents();
        
        
    }

    private void initComponents() {
        
        this.pfguipanel=new PFem2DGuiPanel();
        this.pfguipanel.setPreferredSize(new Dimension(800, 600));
        this.add(this.pfguipanel, BorderLayout.CENTER);
        
        JToolBar toolbar=new JToolBar();
        toolbar.setPreferredSize(new Dimension(100, 40));
        
        toolbar.add(new JButton("open",new javax.swing.ImageIcon(getClass().getResource("/ressources/icons/document-open.png"))));
        toolbar.add(new JButton("mesh",new javax.swing.ImageIcon(getClass().getResource("/ressources/icons/applications-system.png"))));
        toolbar.add(new JButton("screen",new javax.swing.ImageIcon(getClass().getResource("/ressources/icons/camera-photo.png"))));
        toolbar.add(new JSeparator(JSeparator.VERTICAL));
        
        JButton jbClose=new JButton("close",new javax.swing.ImageIcon(getClass().getResource("/ressources/icons/process-stop.png")));
        jbClose.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        toolbar.add(jbClose);
        
        
        this.add(toolbar, BorderLayout.NORTH);
        
        this.pack();
        
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    private PFem2DGuiPanel pfguipanel;
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                new PlegatFem2D_Prepro("Preprocesseur PFEM").setVisible(true);
                
                System.out.println("lancement ok");
            }
        });
        
        
        
    }

}
